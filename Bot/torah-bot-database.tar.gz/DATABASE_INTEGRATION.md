# 💾 Интеграция базы данных Torah Bot

## 📦 Что в архиве

```
torah-bot-database.tar.gz
├── torah-bot-database-backup.sql  (137 KB, 1621 строка)
└── DATABASE_INTEGRATION.md        (эта инструкция)
```

---

## 📊 Что содержит база данных

**Размер:** 137 KB  
**Формат:** PostgreSQL SQL dump  
**Строк:** 1621  

**Таблицы:**
- `users` - подписчики бота (telegram_id, язык, время доставки, статус блокировки)
- `delivery_log` - история доставки сообщений
- `admin_permissions` - права администраторов
- `audit_log` - логи безопасности и действий
- Системные таблицы PostgreSQL

---

## 🔄 У вас есть 2 варианта

### ✅ Вариант 1: Оставить базу на Replit (ПРОСТО)

**Когда использовать:**
- Вы хотите только перенести код в Cursor
- Не хотите настраивать локальный PostgreSQL
- Хотите сохранить все данные как есть

**Что делать:**

1. **В Replit**: Скопируйте `DATABASE_URL` из Secrets
   ```
   Replit → Secrets → DATABASE_URL → Copy
   ```

2. **В Cursor**: Создайте `.env` файл
   ```bash
   # В папке проекта
   cp .env.example .env
   nano .env  # или любой редактор
   ```

3. **Вставьте DATABASE_URL:**
   ```env
   # .env
   DATABASE_URL=postgresql://user:pass@host.postgres.database.replit.app:5432/db
   BOT_TOKEN=ваш_токен
   ADMIN_SECRET=ваш_секрет
   ```

4. **Готово!** Бот будет работать с базой на Replit удалённо.

**Плюсы:**
- ✅ Ничего устанавливать не нужно
- ✅ Данные остаются на месте
- ✅ Работает сразу
- ✅ Бесплатно (в рамках Replit)

**Минусы:**
- ⚠️ Зависимость от Replit
- ⚠️ Нужен интернет для доступа к БД

---

### ✅ Вариант 2: Локальная база данных (ПОЛНАЯ НЕЗАВИСИМОСТЬ)

**Когда использовать:**
- Хотите полную независимость от Replit
- Разрабатываете offline
- Нужен полный контроль над данными

---

## 📥 Шаг 1: Установка PostgreSQL

### macOS:
```bash
# Установить через Homebrew
brew install postgresql@15

# Запустить PostgreSQL
brew services start postgresql@15

# Проверить
psql --version
```

### Linux (Ubuntu/Debian):
```bash
# Установить PostgreSQL
sudo apt update
sudo apt install postgresql postgresql-contrib

# Запустить сервис
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Проверить
psql --version
```

### Windows:
1. Скачайте установщик: https://www.postgresql.org/download/windows/
2. Запустите установку (версия 15+)
3. Запомните пароль для пользователя `postgres`
4. Добавьте PostgreSQL в PATH

---

## 📥 Шаг 2: Создание базы данных

### macOS/Linux:
```bash
# Создать пользователя (если нужно)
createuser -s torah_bot_user

# Создать базу данных
createdb torah_bot

# Проверить
psql -l | grep torah_bot
```

### Windows (через PowerShell):
```bash
# Подключиться к PostgreSQL
psql -U postgres

# В psql консоли:
CREATE DATABASE torah_bot;
\q
```

---

## 📥 Шаг 3: Распаковка архива

```bash
# Распаковать архив
tar -xzf torah-bot-database.tar.gz

# Вы увидите:
# torah-bot-database-backup.sql
# DATABASE_INTEGRATION.md
```

---

## 📥 Шаг 4: Восстановление базы данных

### macOS/Linux:
```bash
# Восстановить из backup
psql torah_bot < torah-bot-database-backup.sql

# Должны увидеть:
# SET
# SET
# CREATE TABLE
# CREATE INDEX
# COPY 264  (пользователи загружены)
# ...
```

### Windows:
```bash
# Через командную строку
psql -U postgres -d torah_bot -f torah-bot-database-backup.sql
```

---

## 📥 Шаг 5: Проверка данных

```bash
# Подключиться к базе
psql torah_bot

# Проверить таблицы
\dt

# Проверить пользователей
SELECT COUNT(*) FROM users;
# Должно быть: несколько сотен пользователей

# Посмотреть первые записи
SELECT telegram_id, username, language FROM users LIMIT 5;

# Выйти
\q
```

---

## ⚙️ Шаг 6: Настройка проекта

### 1. Создать `.env` файл:
```bash
cd torah-bot
cp .env.example .env
```

### 2. Отредактировать `.env`:

**macOS/Linux:**
```env
DATABASE_URL=postgresql://localhost:5432/torah_bot
BOT_TOKEN=ваш_telegram_bot_token
ADMIN_SECRET=ваш_admin_secret
```

**Windows:**
```env
DATABASE_URL=postgresql://postgres:ваш_пароль@localhost:5432/torah_bot
BOT_TOKEN=ваш_telegram_bot_token
ADMIN_SECRET=ваш_admin_secret
```

### 3. Установить зависимости:
```bash
# Создать виртуальное окружение
python3.11 -m venv venv
source venv/bin/activate  # Linux/macOS
# или
venv\Scripts\activate     # Windows

# Установить пакеты
pip install -r requirements.txt
```

---

## 🚀 Шаг 7: Запуск бота

```bash
# Активировать виртуальное окружение
source venv/bin/activate  # Linux/macOS
# или
venv\Scripts\activate     # Windows

# Запустить бота
python unified_webhook_service.py
```

**Должны увидеть:**
```
✅ Database connected successfully
🤖 Bot started in polling mode
📊 Active users: 264
🎯 System ready!
```

---

## 🔍 Устранение проблем

### Ошибка: "psql: command not found"
**Решение:** PostgreSQL не установлен или не в PATH
```bash
# macOS
brew install postgresql@15

# Linux
sudo apt install postgresql-client

# Windows: Добавьте C:\Program Files\PostgreSQL\15\bin в PATH
```

### Ошибка: "database does not exist"
**Решение:** Создайте базу данных
```bash
createdb torah_bot
```

### Ошибка: "connection refused"
**Решение:** PostgreSQL не запущен
```bash
# macOS
brew services start postgresql@15

# Linux
sudo systemctl start postgresql

# Windows: Запустите PostgreSQL из Services
```

### Ошибка: "role does not exist"
**Решение:** Измените DATABASE_URL в .env
```env
# Вместо:
DATABASE_URL=postgresql://localhost:5432/torah_bot

# Используйте:
DATABASE_URL=postgresql://postgres:ваш_пароль@localhost:5432/torah_bot
```

### Ошибка при восстановлении backup
**Решение:** Очистите базу и попробуйте снова
```bash
# Удалить базу
dropdb torah_bot

# Создать заново
createdb torah_bot

# Восстановить
psql torah_bot < torah-bot-database-backup.sql
```

---

## 📊 Проверка успешной интеграции

### Тест 1: Подключение к базе
```bash
psql torah_bot -c "SELECT COUNT(*) FROM users;"
# Должно показать количество пользователей
```

### Тест 2: Запуск бота
```bash
python unified_webhook_service.py
# Должен запуститься без ошибок
```

### Тест 3: Отправка команды в Telegram
```
/start
# Бот должен ответить приветствием
```

### Тест 4: Проверка данных пользователя
В Telegram отправьте:
```
/admin stats
```
Должна появиться статистика с количеством пользователей.

---

## 🔐 Безопасность

### Важно:
1. ✅ Никогда не коммитьте `.env` в git
2. ✅ Используйте сильные пароли для БД
3. ✅ Регулярно делайте backup
4. ✅ Ограничьте доступ к базе данных

### Создание backup (на будущее):
```bash
# Полный backup
pg_dump torah_bot > backup-$(date +%Y%m%d).sql

# Только данные (без структуры)
pg_dump --data-only torah_bot > data-backup.sql

# Только структура (без данных)
pg_dump --schema-only torah_bot > schema-backup.sql
```

---

## ✅ Итоговый чеклист

- [ ] PostgreSQL установлен и запущен
- [ ] База данных `torah_bot` создана
- [ ] Backup восстановлен из `torah-bot-database-backup.sql`
- [ ] Таблицы видны (`\dt` в psql)
- [ ] Пользователи загружены (проверка `SELECT COUNT(*)`)
- [ ] `.env` файл создан и настроен
- [ ] Зависимости установлены (`pip install -r requirements.txt`)
- [ ] Бот запускается без ошибок
- [ ] Бот отвечает на команды в Telegram
- [ ] Статистика показывает правильное количество пользователей

---

## 🎉 Готово!

После выполнения всех шагов у вас будет:
- ✅ Локальная копия базы данных
- ✅ Все пользователи сохранены
- ✅ История доставки восстановлена
- ✅ Полная независимость от Replit
- ✅ Рабочий бот в Cursor

---

## 📞 Нужна помощь?

### Полезные команды PostgreSQL:

```bash
# Список баз данных
psql -l

# Подключиться к базе
psql torah_bot

# Список таблиц
\dt

# Структура таблицы
\d users

# Выполнить SQL
SELECT * FROM users LIMIT 10;

# Выйти
\q
```

### Документация:
- PostgreSQL: https://www.postgresql.org/docs/
- Проект README: см. файл `README.md` в архиве
- Разработка: см. файл `DEVELOPMENT.md`

---

**Версия:** November 2025  
**Статус:** Production-ready  
**Размер БД:** 137 KB (1621 строка SQL)
